#include "userFunctions.h"

double u_InitTemperature(double x, double y, double z) {
	double retVal=0.0;
	
	return retVal;
}
